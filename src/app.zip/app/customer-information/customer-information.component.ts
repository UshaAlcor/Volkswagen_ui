import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AuthService } from '../auth.service';




@Component({
  selector: 'app-customer-information',
  templateUrl: './customer-information.component.html',
  styleUrls: ['./customer-information.component.css']
})
export class CustomerInformationComponent {
 
  inforesponse: any;
  auth: any;
  formdata: any;

  
  original="sme text";
  data: any;
  model!: String[];


  constructor(private  loginAuth: AuthService) { 
    
  }

  //custinfo

  information(){
    this.loginAuth.informationUser(this.model).subscribe(
      (      result: any) => {
        this.inforesponse = result;
        console.log('information', this.inforesponse);
        console.log(Object.keys(this.inforesponse[0].id));


      }
    )
  }

}
