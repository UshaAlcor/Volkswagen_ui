import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import { AuthService } from '../auth.service';



const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();


@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent {
  Roles: any = ['Admin', 'Author', 'Reader'];
  

  title = 'Bizpulse';
  showFiller = false;
  states: string[] = [
    'USA',
    'India',
    'Japan',
    'Australia',
    'Newzealand'
  ];

  details: string[] = [
    'Employee Name',
    'Login Details',
    'Email-Id'
  ];
  auth: any;



  constructor(private  loginAuth: AuthService) { 
    
  }

registerForm = new FormGroup({
  kanjiname: new FormControl("") as unknown as any,
  kanjilastname: new FormControl("") as unknown as any,
  kananame: new FormControl("") as unknown as any,
  kanalastname: new FormControl("") as unknown as any,
  dob: new FormControl("") as unknown as any,
  gender: new FormControl("") as unknown as any,
  email: new FormControl('', [Validators.required, Validators.email]) as unknown as any,
  cell1: new FormControl("") as unknown as any,
  cell2: new FormControl("") as unknown as any,
  add1: new FormControl("") as unknown as any,
  add2: new FormControl("") as unknown as any,
  add3: new FormControl("") as unknown as any,
  phone1: new FormControl("") as unknown as any,
  phone2: new FormControl("") as unknown as any,

});

FormGroup: string | undefined;



isUserValid: boolean =false;

registerSubmitted() {
  console.log(this.registerForm)
  this.loginAuth.registerUser([
    this.registerForm.value.kanjiname, 
    this.registerForm.value.kanjilastname,
    this.registerForm.value.kananame,
    this.registerForm.value.kanalastname,
    this.registerForm.value.dob,
    this.registerForm.value.email,
    this.registerForm.value.gender,
    this.registerForm.value.cell1,
    this.registerForm.value.cell2,
    this.registerForm.value.add1,
    this.registerForm.value.add2,
    this.registerForm.value.add3,
    this.registerForm.value.phone1,
    this.registerForm.value.phone2,
  ]).subscribe((res: any) => {
       if (res == 'Failure'){
        this.isUserValid = false;
        alert('Login Unsuccessful');
       } else {
        this.isUserValid =true;
        alert('Login Successful');
       }
  });
}


get Kanjiname(): FormControl {
  return this.registerForm.get('kanjiname')as FormControl;

}

get Kanjilastname(): FormControl {
  return this.registerForm.get('kanjilastname')as FormControl;
}

get kananame(): FormControl {
  return this.registerForm.get('kananame')as FormControl;
}

get Kanalastname(): FormControl {
  return this.registerForm.get('kanalastname')as FormControl;
}

get dob(): FormControl {
  return this.registerForm.get('dob')as FormControl;
}

get email(): FormControl {
  return this.registerForm.get('email')as FormControl;
}

get gender(): FormControl {
  return this.registerForm.get('gender')as FormControl;
}

get Cell1(): FormControl {
  return this.registerForm.get('cell1')as FormControl;
}

get Cell2(): FormControl {
  return this.registerForm.get('cell2')as FormControl;
}

get Add1(): FormControl {
  return this.registerForm.get('add1')as FormControl;
}

get Add2(): FormControl {
  return this.registerForm.get('add2')as FormControl;
}

get Add3(): FormControl {
  return this.registerForm.get('add3')as FormControl;
}

get Phone1(): FormControl {
  return this.registerForm.get('phone1')as FormControl;
}

get Phone2(): FormControl {
  return this.registerForm.get('phone2')as FormControl;
}

_locale = 'ja-JP';

getDateFormatString(): string {
  if (this._locale === 'ja-JP') {
    return 'YYYY/MM/DD';
  } else if (this._locale === 'fr') {
    return 'DD/MM/YYYY';
  }
  return '';
}

}
