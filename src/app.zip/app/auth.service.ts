import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  httpClient: any;
  loginUser: any;

  constructor(private http: HttpClient) {}

  public Base_URL= "http://localhost:8000/";

  public getDataWithParams(url: string, params?:HttpParams){
    return this.httpClient.get('${BaseURL}${url}',{params});
  }


  public postDataWithHeader(url: string, body: any, params?:HttpParams, headers?: HttpHeaders){
    return this.httpClient.post('${BaseURL}${url}',body, {headers, params, responseType:'json'});
  }

  public postDataWithParams(url: string, body: any, params?:HttpParams, headers?: HttpHeaders){
    return this.httpClient.post('${BaseURL}${url}',body, {headers, params, responseType:'text'});
  }

  informationUser(user: Array<String>) {
    return this.http.get(
      this.Base_URL+ 'CustInfo',
    );
  }

  registerUser(user: Array<String>) {

  return this.http.post(
  this.Base_URL+ 'CustInfo',
  {
  kanjiname: user[0],
  kanjilastname: user[1],
  kananame: user[2],
  kanalastname: user[3] ,
  dob: user[4],
  email: user[5],
  gender: user[6],
  cell1: user[7],
  cell2: user[8],
  add1: user[9],
  add2: user[10],
  add3: user[11] ,
  phone1: user[12],
  phone2: user[13]
   },
      {
        responseType: 'text'
      }
    );
  }

}
